#include <iostream>
#include <fstream>
#include <conio.h>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <process.h>
#include <time.h>
#include <cstring>
#include <iomanip>
#include <utility>
#include <vector>
using namespace std;

void Main_Menu(void);
void close(void);

struct MovieDetails
{
    string movieName;
    string duration;
    int numberofRuns;
    int theatre[5];
    string timing[5];
    int platinum_seatsAvailable[5];
    int gold_seatsAvailable[5];
    float rating;
};

struct Buyfood
{
    vector<pair<string, float>> food_Menu = {{"POPCORN", 249.99}, {"TACO", 99.99}, {"COKE", 75.50}, {"FANTA", 75.50}, {"LIMCA", 75.50}, {"BURGER", 65}, {"PIZZA", 149.49}, {"SAMOSA", 45}, {"PATTY", 30}, {"PASTA", 199.99}};

    int userfoodchoice[10], foodQty[10];
    float foodbill = 0;
    void display_food_menu()
    {
        cout << "\nThe Food Menu : \n";
        cout.width(5);
        cout << "Sr.No";
        cout.width(12);
        cout << "Item Name";
        cout.width(11);
        cout << "Price\n\n";
        for (int i = 0; i < food_Menu.size(); i++)
        {
            cout.width(3);
            cout << i + 1;
            cout.width(11);
            cout << food_Menu[i].first;
            cout.width(11);
            cout << fixed << setprecision(2) << food_Menu[i].second;
            cout << endl;
        }
    }
};

class Staff
{
public:
    void Staff_info(void);
};
class Movie
{
protected:
    int movieNo;
    struct MovieDetails movie[8];
    int numberofMovies = 0;

    // for File Handling
    bool inputMovieFlag = 0;
    bool storeMovieFlag = 0;
    void inputMovie();
    void storeMovie();

    bool displayMoviesList();
    void displayMovieDetails(int);
    void addMovie();
    void removeMovie(int);

    void userMovieDetails(int);
    void bookTickets(int);

public:
    void Movie_Management(void);
    void Theatre_details(void);

    //User Functions
    void Movie_booking(void);
    void Feedback(void);
};

class Admin : public Staff, public Movie
{
public:
    void Password_Admin(void);
    void Admin_Menu(void);
    void Admin_GoBack_Menu(void);
    void Food_management(void);
};

class User : public Movie
{
public:
    string name;
    long int contact_no;
    string email;
    int ticket_no = 20;
    void User_Menu(void);
    void User_GoBack_Menu(void);
    void Card_details(void);
    int Ticket_pay(int);
    float Food_pay(void);
    void getdetails(void)
    {
        cout << "\n\t\t\tENTER YOUR DETAILS";
        cout << "\n\t\t\tName: ";
        cin >> name;
        cout << "\n\t\t\tcontact No.: ";
        cin >> contact_no;
        cin.ignore();
        cout << "\n\t\t\tEmail Address: ";
        cin >> email;
    }
    void showdetails(void)
    {
        cout << "\t\t\tUSER DETAILS";
        cout << "\n\n\t\t\t Name of the user: " << name;
        cout << "\n\t\t\tContact Number: " << contact_no;
        cout << "\n\t\t\tEmail Address: " << email;
        cout << "\n\t\t\tTicket Number: " << ticket_no;
    }
};

class Feedbacks
{
public:
    float movie_rating, food_rating, theatre_rating;
    Feedbacks()
    {
        movie_rating = 0;
        food_rating = 0;
        theatre_rating = 0;
    }
    Feedbacks(float movie_rate, float food_rate, float theatre_rate)
    {
        this->movie_rating = movie_rate;
        this->food_rating = food_rate;
        this->theatre_rating = theatre_rate;
        float avg_rating = (movie_rating + food_rating + theatre_rating) / 3;
        cout << "\n\nAverage rating is: " << avg_rating;
    }
};

template <class X, class Y>
void Bill(X a, Y b)
{
    std::cout << "\n\n\t\t\tTicket bill: Rs." << a << endl;
    std::cout << "\n\t\t\tFood bill: Rs." << b << endl;
    std::cout << "\n\t\t\tTotal bill: " << a + b;
}

template <class M, class N>
N Amount(M x, N y)
{
    return x + y;
}

void Staff::Staff_info()
{
    string srg;
    ifstream filestream("staff_info.txt");
    if (filestream.is_open())
    {
        while (getline(filestream, srg))
        {
            cout << srg << endl;
        }
        filestream.close();
    }
    else
    {
        cout << "File opening is fail." << endl;
    }
    Admin admin;
    admin.Admin_GoBack_Menu();
}

void Movie::Movie_Management(void)
{
    if (!inputMovieFlag)
    {
        inputMovie();
    }
    int option;

    cout << "\n\n"
         << setw(50) << "Welcome to the Movies Section \n\n";
    cout << "\n\n"
         << setw(33) << "1.SEE MOVIE DETAILS\n"
         << setw(25) << "2.ADD MOVIE\n"
         << setw(28) << "3.REMOVE MOVIE\n"
         << setw(48) << "(Press any other key to Go Back)\n\n\n\n"
         << setw(30) << " Enter your choice:";
    cin >> option;
    system("cls");
    switch (option)
    {
    case 1:
        if (displayMoviesList())
        {
            cout << "Select Movie to see its details : ";
            cin >> movieNo;
            if (movieNo <= numberofMovies)
            {
                displayMovieDetails(movieNo);
            }
            else
            {
                cout << "No such movie!" << endl;
                cout << "Press any key to go back\n\n";
                cin.ignore();
                cin.get();
                Movie::Movie_Management();
            }
        }
        break;

    case 2:
        addMovie();
        break;
    case 3:
        displayMoviesList();
        cout << "Select Movie to remove : ";
        cin >> movieNo;
        if (movieNo <= numberofMovies)
        {
            removeMovie(movieNo);
        }
        else
        {
            cout << "No such movie!" << endl;
            cout << "Press any key to go back\n\n";
            cin.ignore();
            cin.get();
            Movie::Movie_Management();
        }
        break;

    default:
        Admin admin;
        admin.Admin_GoBack_Menu();
        break;
    }
}

void Movie::inputMovie()
{
    ifstream fmovie;
    fmovie.open("Movie_Details.txt", ios::in);
    string blank;
    if (fmovie.is_open())
    {

        numberofMovies = 0;

        while (getline(fmovie, blank))
        {
            getline(fmovie, movie[numberofMovies].movieName);
            getline(fmovie, movie[numberofMovies].duration);
            fmovie >> movie[numberofMovies].numberofRuns;
            for (int i = 0; i < movie[numberofMovies].numberofRuns; i++)
            {
                fmovie >> movie[numberofMovies].theatre[i];
                getline(fmovie, blank);
                getline(fmovie, movie[numberofMovies].timing[i]);
                fmovie >> movie[numberofMovies].platinum_seatsAvailable[i];
                fmovie >> movie[numberofMovies].gold_seatsAvailable[i];
            }
            fmovie >> movie[numberofMovies].rating;
            getline(fmovie, blank);
            numberofMovies++;
        }
        inputMovieFlag = true;
        storeMovieFlag = false;
    }
    else
    {
        cout << "Movie File not opened" << endl;
    }
    fmovie.close();
}
void Movie::storeMovie()
{

    ofstream fmovie;
    fmovie.open("Movie_Details.txt", ios::out);
    if (fmovie.is_open())
    {

        for (int i = 0; i < numberofMovies; i++)
        {
            fmovie << endl
                   << movie[i].movieName << endl
                   << movie[i].duration << endl
                   << movie[i].numberofRuns << endl;
            for (int j = 0; j < movie[i].numberofRuns; j++)
            {
                fmovie << movie[i].theatre[j] << endl
                       << movie[i].timing[j] << endl
                       << movie[i].platinum_seatsAvailable[j] << endl
                       << movie[i].gold_seatsAvailable[j] << endl;
            }
            fmovie << movie[i].rating;
            if (i < numberofMovies - 1)
            {
                fmovie << endl;
            }
        }
        storeMovieFlag = true;
        inputMovieFlag = false;
    }
    else
    {
        cout << "Movie file for Writing not opened." << endl;
    }
    fmovie.close();
}

void Movie::Movie_booking()
{
    if (!inputMovieFlag)
    {
        inputMovie();
    }

    User user;
    if (displayMoviesList())
    {
        cout << "\n(Press 0 to go back to User Menu)" << endl;
        cout << "\nSelect Movie to see its details : ";
        cin >> movieNo;
        if (movieNo == 0)
        {
            user.User_Menu();
        }
        if (movieNo <= numberofMovies)
        {
            userMovieDetails(movieNo);
        }
        else
        {
            cout << "No such movie!" << endl;
            cout << "Press any key to go back\n\n";
            cin.ignore();
            cin.get();
            user.User_Menu();
        }
        char choice;
        cout << "\nDo you want to book tickets for this movie ? " << endl
             << "\nPress y to book tickets or anything else to go back" << endl
             << "\nEnter your choice : ";
        cin >> choice;
        system("cls");
        if (choice == 'y' || choice == 'Y')
        {
            bookTickets(movieNo);
        }
        else
        {
            Movie_booking();
        }
    }
}
bool Movie::displayMoviesList(void)
{
    if (numberofMovies == 0)
    {
        cout << "No Movies running currently !" << endl;
        return false;
    }
    for (int i = 0; i < numberofMovies; i++)
    {
        cout << i + 1 << ". " << movie[i].movieName << endl;
    }
    return true;
}
void Movie::displayMovieDetails(int movieNo)
{
    system("cls");
    cout << "\t\t\t" << movie[movieNo - 1].movieName << endl
         << "Duration of the movie : " << movie[movieNo - 1].duration << endl
         << "Numer of runs of this movie : " << movie[movieNo - 1].numberofRuns << endl;
    for (int i = 0; i < movie[movieNo - 1].numberofRuns; i++)
    {
        cout << "\n\tTheatre : " << movie[movieNo - 1].theatre[i] << "\tTiming : " << movie[movieNo - 1].timing[i] << endl
             << "\tSeats available : \n"
             << "\t\t Platinum Seats : " << movie[movieNo - 1].platinum_seatsAvailable[i] << endl
             << "\t\t Gold Seats : " << movie[movieNo - 1].gold_seatsAvailable[i] << endl;
    }
    cout << "Rating of the movie : " << movie[movieNo - 1].rating << " stars out of 5" << endl;
    cout << "Press any key to go back\n\n";
    cin.ignore();
    cin.get();
    Movie::Movie_Management();
}

void Movie::addMovie(void)
{
    cout << "\n\n"
         << setw(40) << "Adding a Movie : \n\n";
    cout << setw(45) << "Enter all the details :\n";
    cout << "\tEnter the name of movie : ";
    cin.ignore();
    getline(cin, movie[numberofMovies].movieName);
    cout << "\n\tEnter the duration of movie (in _ hr _ min format) : ";
    getline(cin, movie[numberofMovies].duration);
    cout << setw(30) << "\n\tNumber of Runs for this movie : ";
    cin >> movie[numberofMovies].numberofRuns;
    while (movie[numberofMovies].numberofRuns > 5)
    {
        cout << "\tMaximum number of Runs for a movie can be 5 only\n\n"
             << "\tEnter number of Runs again : ";
        cin >> movie[numberofMovies].numberofRuns;
    }
    cout << "\nEntering the theatre hall and timing for each run" << endl;
    for (int i = 0; i < movie[numberofMovies].numberofRuns; i++)
    {
        cout << "\nRun " << i + 1 << " : \n";
        cout << "\tTheatre Hall Number [1,2 or 3] : ";
        cin >> movie[numberofMovies].theatre[i];
        while (movie[numberofMovies].theatre[i] < 1 || movie[numberofMovies].theatre[i] > 3)
        { // if wrong theatre number entered
            cout << "\tWrong Theatre number entered!\n\n"
                 << "\tEnter Theatre Hall Number [1,2 or 3] : ";
            cin >> movie[numberofMovies].theatre[i];
        }
        cout << "\tEnter Timing : ";
        cin.ignore();
        getline(cin, movie[numberofMovies].timing[i]);
        movie[numberofMovies].platinum_seatsAvailable[i] = 50;
        movie[numberofMovies].gold_seatsAvailable[i] = 75;
    }
    cout << "\nEnter the current rating of movie : ";
    cin >> movie[numberofMovies].rating;

    numberofMovies++;
    cout << "\n\n Movie Added successfully !";
    if (!storeMovieFlag)
    {
        storeMovie();
    }
    cout << "\nPress any key to go back\n\n";
    cin.ignore();
    cin.get();
    Movie::Movie_Management();
}
void Movie::removeMovie(int movieNo)
{
    for (int i = movieNo - 1; i < numberofMovies - 1; i++)
    {
        movie[i] = movie[i + 1];
    }
    numberofMovies--;
    cout << "Movie deleted successfully !";
    if (!storeMovieFlag)
    {
        storeMovie();
    }
    cout << "\nPress any key to go back\n\n";
    cin.ignore();
    cin.get();
    Movie::Movie_Management();
}

void Movie::userMovieDetails(int movieNo)
{
    system("cls");
    cout << "\t\t\t" << movie[movieNo - 1].movieName << endl
         << "\nDuration of the movie : " << movie[movieNo - 1].duration << endl
         << "Rating of the movie : " << movie[movieNo - 1].rating << " stars out of 5" << endl;
}

void Movie::bookTickets(int movieNo)
{
    cout << "This movie is running at following timings : \n\n";

    for (int i = 0; i < movie[movieNo - 1].numberofRuns; i++)
    {
        cout << "< " << i + 1 << " > Timing : " << movie[movieNo - 1].timing[i] << endl
             << "Theatre hall : " << movie[movieNo - 1].theatre[i] << endl
             << "\tSeats available : \n"
             << "\t\t Platinum Seats : " << movie[movieNo - 1].platinum_seatsAvailable[i] << endl
             << "\t\t Gold Seats : " << movie[movieNo - 1].gold_seatsAvailable[i] << endl
             << endl;
    }
    int movieRun;
    cout << "Select the timing of which you want to book ticket : ";
    cin >> movieRun;
    while (movieRun > movie[movieNo - 1].numberofRuns)
    {
        cout << "This is not an available timing !" << endl
             << "Choose the time again : ";
        cin >> movieRun;
    }
    int numberofTickets;
    cout << "\nEnter the number of tickets you want to book : ";
    cin >> numberofTickets;
    User obj1;
    int amount = obj1.Ticket_pay(numberofTickets);
    cout << "\nThank You for booking the tickets" << endl;
    char ch;
    cin.ignore();
    cout << "Do you want to buy any Food item(y/n)" << ch;
    cin >> ch;
    User card;
    float t1 = 0;
    char payment;
    User ticket;
    if (ch == 'y' || ch == 'Y')
    {
        struct Buyfood obj;
        obj.display_food_menu();
        User pay;
        t1 = pay.Food_pay();
        Bill(amount, t1);
        ticket.getdetails();
        system("cls");
        cout << "\n\n\t\t\tDO YOU WANT TO PAY BY CARD(Y/N):";
        cin >> payment;
        if (payment == 'y' || payment == 'Y')
        {
            card.Card_details();
            ticket.showdetails();
            cout << "\n\n"
                 << "Amount paid: Rs." << Amount(amount, t1) << endl;
            cin.ignore();
            cin.get();
        }
        else
        {
            system("cls");
            ticket.showdetails();
            cout << "\n\n"
                 << "Please pay below mentioned amount at the counter:\n\n\t\t\t Rs." << Amount(amount, t1) << endl;
            cin.ignore();
            cin.get();
        }
    }
    else
    {
        cout << "\nWe hope you enjoy the movie!" << endl;
        Bill(amount, t1);
        ticket.getdetails();
        cout << "\n\n\t\t\tDO YOU WANT TO PAY BY CARD(Y/N):";
        cin >> payment;
        if (payment == 'y' || payment == 'Y')
        {
            card.Card_details();
            system("cls");
            ticket.showdetails();
            cout << "\n\n"
                 << "Amount paid: Rs." << Amount(amount, t1) << endl;
            cin.ignore();
            cin.get();
        }
        else
        {
            system("cls");
            ticket.showdetails();
            cout << "\n\n"
                 << "Please pay below mentioned amount at the counter:\n\n\t\t\t Rs." << Amount(amount, t1) << endl;
            cin.ignore();
            cin.get();
        }
    }
    cout << "\n"
         << "press any key to continue........";
    User user;
    user.User_Menu();
}

void Movie::Theatre_details(void)
{
    int n;
    cout << "\n\n"
         << setw(55) << "THEATRE HALL DETAILS";
    cout << "\n\n"
         << setw(40) << "1.PRESS 1 FOR HALL 1 DETAILS\n"
         << setw(40) << "2.PRESS 2 FOR HALL 2 DETAILS\n"
         << setw(40) << "3.PRESS 3 FOR HALL 3 DETAILS\n"
         << setw(22) << "4.EXIT\n\n\n\n\n"
         << setw(30) << " Enter your choice:";
    cin >> n;
    system("cls");
    switch (n)
    {
    case 1:
    {
        string S1;
        ifstream filestream("HALL_1.txt");
        if (filestream.is_open())
        {
            while (getline(filestream, S1))
            {
                cout << S1 << endl;
            }
            filestream.close();
        }
        else
        {
            cout << "File opening is fail." << endl;
        }
    }
    break;
    case 2:
    {
        string S2;
        ifstream filestream("HALL_2.txt");
        if (filestream.is_open())
        {
            while (getline(filestream, S2))
            {
                cout << S2 << endl;
            }
            filestream.close();
        }
        else
        {
            cout << "File opening is fail." << endl;
        }
    }
    break;
    case 3:
    {
        string S3;
        ifstream filestream("HALL_3.txt");
        if (filestream.is_open())
        {
            while (getline(filestream, S3))
            {
                cout << S3 << endl;
            }
            filestream.close();
        }
        else
        {
            cout << "File opening is fail." << endl;
        }
    }
    break;
    case 4:
        close();
        break;
    }
    Admin admin;
    admin.Admin_GoBack_Menu();
}
void Admin::Food_management(void)
{
    struct Buyfood adminFood;
    char ch;
    adminFood.display_food_menu();
    cout << "\nDo you want to make any changes in the Food Menu (y/n) : ";
    cin >> ch;
    if (ch == 'y' || ch == 'Y')
    {
        int choice;
        cout << "\n Press 1 to Add Food Item ";
        cout << "\n Press 2 to Delete a Food Item ";
        cout << "\n Enter Your Choice : ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            cout << "ADDING A FOOD ITEM : " << endl;
            string foodName;
            int foodPrice;
            cout << "\nEnter the name of Food Item : ";
            cin.ignore();
            getline(cin, foodName);
            cout << "Enter the price of Food Item : ";
            cin >> foodPrice;
            adminFood.food_Menu.push_back({foodName, foodPrice});
            cout << "Food Item added successfully!" << endl;
            cin.ignore();
            cin.get();
            cout << "Showing the updated list : " << endl;
            adminFood.display_food_menu();
            cin.get();
            Admin::Admin_Menu();
            break;
        }
        case 2:
        {
            cout << "Enter the serial number of the Food Item to be deleted : ";
            int foodNo;
            cin >> foodNo;
            for (int i = foodNo - 1; i < adminFood.food_Menu.size() - 1; i++)
            {
                adminFood.food_Menu[i] = adminFood.food_Menu[i + 1];
            }
            adminFood.food_Menu.pop_back();
            cout << "Food Item deleted successfully !" << endl;
            cin.ignore();
            cin.get();
            cout << "Showing the updated list : " << endl;
            adminFood.display_food_menu();
            cin.get();
            Admin::Admin_Menu();
            break;
        }

        default:
        {
            cout << "Wrong Menu option entered." << endl;
            Admin admin;
            admin.Admin_GoBack_Menu();
        }
        }
    }

    else
    {
        Admin admin;
        admin.Admin_GoBack_Menu();
    }
}

int User::Ticket_pay(int a)
{
    int normal, gold, amt = 0, id;

    cout << "\n\n\t\tThank you for selecting the show. Now we request you to select your type of seating \n\n\t\t\t\t 1.Platinum Class \n\t\t\t\t OR \n\t\t\t\t 2. Gold Class : ";
    int c;
    cin >> c;
    if (c == 1)
    {
        cout << "\n\n\t\t\tYou selected for a Platinum class \n\n\t\t\t\t";
        system("PAUSE");
        system("CLS");
        amt = a * 400;
        cout << "\n\t\t\t"
             << "Amount you need to pay for your Tickets: Rs." << amt << "\n";
    }
    else
    {
        cout << "\n\n\t\t\tYou selected for the Gold Class \n\t\t\t\t";
        system("PAUSE");
        system("CLS");
        amt = a * 700;
        cout << "\n\t\t\t"
             << "Amount you need to pay for your Tickets: Rs." << amt << "\n";
    }
    return amt;
}

float User::Food_pay()
{
    struct Buyfood obj;
    int qty, i = 0, temp;
    char ch;
    do
    {
        qty = 0;
        cout << "\n\n\n Enter the Serial No. for the Food of Your Choice : ";
        cin >> obj.userfoodchoice[i];
        cout << "\n Quantity : ";
        cin >> qty;
        obj.foodQty[i] = qty;
        obj.foodbill += qty * (obj.food_Menu[obj.userfoodchoice[i] - 1].second);
        cout << "\n Would you like to Select More Items (Y/N) : ";
        cin >> ch;
        ++i;
    } while (ch == 'y' || ch == 'Y');

    return obj.foodbill;
}

void User::Card_details()
{
    time_t t = time(NULL);
    tm *timePtr = localtime(&t);
    cout << "\n\n\t\t\t ENTER CARD DETAILS TO PROCEED";
    cout << "\n\n\t\t\tName of the card holder: ";
    string name;
    cin.ignore();
    getline(cin, name);

    cout << "\n\t\t\tEnter the card number: ";
    char Card[16];
    gets(Card);

    int expirymm, expiryyy;

    cout << "Enter Expiry : " << endl;
    cout << "\tMonth(MM) : ";
    cin >> expirymm;
    cout << "\tYear(YY) : ";
    cin >> expiryyy;
    while (expirymm > 12 || expiryyy < (timePtr->tm_year + 1900))
    {
        if (expirymm > 12)
        {
            cout << "\t\t\t\tEnter the month again: ";
            cin >> expirymm;
        }
        if (expiryyy < (timePtr->tm_year + 1900))
        {
            cout << "\t\t\t\tPlease enter a valid year: ";
            cin >> expiryyy;
        }
        break;
    }
    int h;
    cout << "\t\t\t\tEnter the CVV/CVV2: ";
    cin >> h;
    cin.get();
    cout << "press any key to continue.....";
    system("cls");
}

void Movie::Feedback(void)
{
    float movie_rating, food_rating, theatre_rating;
    cout << "\n\tWELCOME USER!\n\n\tThank you for visiting here\n\tPlease give ratings so that we can improve our services\n";
    cout << "\nEnter the movie rating out of 5:\t";
    cin >> movie_rating;
    cout << "\nEnter the food rating out of 5:\t\t";
    cin >> food_rating;
    cout << "\nEnter the theatre hall services rating out of 5:\t";
    cin >> theatre_rating;
    system("cls");
    cout << "\n\n\tMovie Rating:" << movie_rating;
    cout << "\n\n\tFood Rating:" << food_rating;
    cout << "\n\n\tTheatre Hall Rating:" << theatre_rating;
    Feedbacks f1(movie_rating, food_rating, theatre_rating);
    cout << "\n\nThank you for your valuable time!\n\nKindly visit again";
    User user;
    user.User_GoBack_Menu();
}

void Admin::Password_Admin(void)
{
    system("cls");
    string pass;
    int i = 0;

    do
    {
        cout << "\nYou need to enter the password in order to access the administrator informantion";
        cout << "\n\n\n\t\t Enter Your Password : ";
        cin >> pass;
        try
        {
            string password = "admin_1234";

            if (password == pass)
            {
                system("cls");
                Admin sign;
                sign.Admin_Menu();
            }

            else
            {
                cout << "\nYou Are No Admin\n";
                i++;
                cout << '\n'
                     << 5 - i << " Trie(s) More Left";
                throw(pass);
            }
        }
        catch (string pass)
        {
            system("cls");
            cout << "Access denied\n";
            cout << "You entered " << pass;
        }
    } while (i > 0 && i < 5);
    Main_Menu();
}

void Main_Menu(void)
{
    int choice;
    system("cls");
    cout << "\n\n"
         << setw(63) << "MOVIE HALL MANAGEMENT SYSTEM";
    cout << "\n\n\n"
         << setw(65) << "\xB2\xB2\xB2\xB2\xB2\xB2\xB2 WELCOME TO THE MAIN MENU \xB2\xB2\xB2\xB2\xB2\xB2\xB2";
    cout << "\n\n"
         << setw(30) << "1.ADMIN MENU\n"
         << setw(29) << "2.USER MENU\n"
         << setw(28) << "3.EXIT\n\n\n\n\n"
         << setw(30) << " Enter your choice:";
    cin >> choice;

    system("cls");
    Admin admin;
    User user;
    switch (choice)
    {
    case 1:
        admin.Password_Admin();
        break;
    case 2:
        user.User_Menu();
        break;
    case 3:
        close();
        break;
    }
}
void Admin::Admin_Menu(void)
{
    int option;

    system("cls");

    cout << "\n\n"
         << setw(63) << "MOVIE HALL MANAGEMENT SYSTEM";
    cout << "\n\n\n"
         << setw(65) << "\xB2\xB2\xB2\xB2\xB2\xB2\xB2 WELCOME TO THE ADMIN MENU \xB2\xB2\xB2\xB2\xB2\xB2\xB2";
    cout << "\n\n"
         << setw(35) << "1.STAFF INFORMATION\n"
         << setw(31) << "2.MOVIE DETAILS\n"
         << setw(38) << "3.THEATER HALL DETAILS\n"
         << setw(33) << "4.FOOD MANAGEMENT\n"
         << setw(35) << "5.BACK TO MAIN MENU\n"
         << setw(26) << "6.Exit\n\n\n\n\n"
         << setw(30) << "Enter your choice:";
    cin >> option;
    system("cls");
    Admin admin;

    switch (option)
    {
    case 1:
        admin.Staff_info();
        break;
    case 2:
        admin.Movie_Management();
        break;
    case 3:
        admin.Theatre_details();
        break;
    case 4:
        admin.Food_management();
        break;
    case 5:
        Main_Menu();
        break;
    case 6:
        close();
        break;
    }
}
void User::User_Menu(void)
{
    system("cls");

    cout << "\n\n"
         << setw(63) << "MOVIE HALL MANAGEMENT SYSTEM";
    cout << "\n\n\n"
         << setw(65) << "\xB2\xB2\xB2\xB2\xB2\xB2\xB2 WELCOME TO THE USER MENU \xB2\xB2\xB2\xB2\xB2\xB2\xB2";
    cout << "\n\n"
         << setw(47) << "Welcome Customer!";
    cout << "\n\n"
         << setw(45) << "<1> Movie Details & Bookings";
    cout << "\n"
         << setw(28) << "<2> Rate Us";
    cout << "\n"
         << setw(31) << "<3> Contact Us";
    cout << "\n"
         << setw(48) << "<4> Go Back to the Main Menu \n\n";
    int option;
    cout << setw(36) << "Select an option : ";
    cin >> option;
    system("cls");
    switch (option)
    {
    case 1:
        Movie::Movie_booking();
        break;
    case 2:
        Movie::Feedback();
        break;
    case 3:
        cout << "Contact us via Sourcecodester or #123456789";
        break;
    case 4:
        Main_Menu();
        break;
    default:
        close();
    }
}

void Admin::Admin_GoBack_Menu()
{
    int choice;
    cout << "\n\n"
         << setw(49) << "1.PRESS 1 TO GO BACK TO MAIN MENU\n"
         << setw(50) << "2.PRESS 2 TO GO BACK TO ADMIN MENU\n"
         << setw(26) << "3.EXIT\n\n\n\n\n"
         << setw(30) << "Enter your choice:";
    cin >> choice;
    system("cls");
    switch (choice)
    {
    case 1:
        Main_Menu();
        break;
    case 2:
        Admin::Admin_Menu();
        break;
    case 3:
        close();
        break;
    }
}

void User::User_GoBack_Menu(void)
{
    int choice;
    cout << "\n\n"
         << setw(50) << "1.PRESS 1 TO GO BACK TO MAIN MENU\n"
         << setw(50) << "2.PRESS 2 TO GO BACK TO USER MENU\n"
         << setw(27) << "3.EXIT\n\n\n\n\n"
         << setw(30) << " Enter your choice:";
    cin >> choice;
    system("cls");
    switch (choice)
    {
    case 1:
        Main_Menu();
        break;
    case 2:
        User::User_Menu();
        break;
    case 3:
        close();
        break;
    }
}

void close(void)
{
    system("cls");
    cout << "\n\n\n\nThankyou for visiting\n";
    cout << "\nPress any key to exit ";
    cin.ignore();
    cin.get();
    exit(0);
}

int main()
{
    Main_Menu();

    return 0;
}